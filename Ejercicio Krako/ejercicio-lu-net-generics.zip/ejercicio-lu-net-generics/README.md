# Ejercicio LU net Generics


Este ejercicio consiste de implementar en el proyecto de consola las interfaces presentadas en la libreria provista, siguiendo las reglas descripta en la documentacion de la clase.
