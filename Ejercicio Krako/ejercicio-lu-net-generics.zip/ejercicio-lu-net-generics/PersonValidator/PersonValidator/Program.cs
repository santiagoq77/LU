﻿using PersonRepository.Interfaces;

namespace PersonValidator
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
